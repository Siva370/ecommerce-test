package com.siva.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.siva.app.domain.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {
	
	
	
}
