package com.siva.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.siva.app.domain.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {
	
	
	
}
