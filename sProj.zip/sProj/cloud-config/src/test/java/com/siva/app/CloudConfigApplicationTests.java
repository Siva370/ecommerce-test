package com.siva.app;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudConfigApplicationTests {
	
	
	
}






