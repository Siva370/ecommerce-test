package com.siva.app.repository;

import com.siva.app.domain.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {
	
	
	
}
