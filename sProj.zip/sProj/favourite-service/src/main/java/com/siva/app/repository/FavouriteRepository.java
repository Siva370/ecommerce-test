package com.siva.app.repository;

import com.siva.app.domain.id.FavouriteId;
import org.springframework.data.jpa.repository.JpaRepository;

import com.siva.app.domain.Favourite;

public interface FavouriteRepository extends JpaRepository<Favourite, FavouriteId> {
	
	
	
}
