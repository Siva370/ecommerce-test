
INSERT INTO order_items
(product_id, order_id, ordered_quantity) VALUES
(1, 1, 2),
(1, 2, 1),
(2, 1, 1),
(2, 2, 1);

