
INSERT INTO verification_tokens
(credential_id, verif_token, expire_date) VALUES
(1, '', '2021-12-31'),
(2, '', '2021-12-31'),
(3, '', '2021-12-31'),
(4, '', '2021-12-31');

