package com.siva.app.repository;

import com.siva.app.domain.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Integer> {
	
	
	
}
