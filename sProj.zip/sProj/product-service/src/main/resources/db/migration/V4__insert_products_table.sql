
INSERT INTO products
(category_id, product_title, image_url, sku, price_unit, quantity) VALUES
(1, 'asus', 'xxx', 'dfqejklejrkn', 0, 50),
(1, 'hp', 'xxx', 'zsejfedbjh', 0, 50),
(2, 'Armani', 'xxx', 'fjdvf', 0, 50),
(3, 'GTA', 'xxx', 'qsdkjnvfrekjrf', 0, 50);

